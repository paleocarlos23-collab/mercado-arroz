// ============================================
// MERCADO ARROZ - JAVASCRIPT APPLICATION
// ============================================

// ============================================
// STATE MANAGEMENT & DATABASE
// ============================================

class MercadoArrozApp {
    constructor() {
        this.currentUser = null;
        this.currentPage = 'landing';
        this.currentChatId = null;
        this.initializeDatabase();
        this.loadUserSession();
        this.initializeApp();
    }

    // Initialize mock database in localStorage
    initializeDatabase() {
        if (!localStorage.getItem('mercadoArroz_initialized')) {
            // Sample Users
            const users = [
                {
                    id: 'user_1',
                    type: 'producer',
                    name: 'João Silva',
                    document: '123.456.789-00',
                    email: 'joao.silva@email.com',
                    password: '123456',
                    phone: '(51) 99999-9999',
                    city: 'Cachoeira do Sul',
                    state: 'RS',
                    rating: 4.8,
                    reviewCount: 32,
                    farmArea: 250,
                    avgProduction: 1200,
                    varieties: ['IRGA 424', 'GURI INTA CL', 'BR-IRGA 409'],
                    certifications: ['Orgânico', 'GlobalGAP'],
                    createdAt: '2024-01-15'
                },
                {
                    id: 'user_2',
                    type: 'industry',
                    name: 'Indústria Riz S.A.',
                    document: '12.345.678/0001-90',
                    email: 'contato@riz.com.br',
                    password: '123456',
                    phone: '(51) 3000-0000',
                    city: 'Porto Alegre',
                    state: 'RS',
                    rating: 4.9,
                    reviewCount: 156,
                    capacity: 5000,
                    varieties: ['IRGA 424', 'IRGA 424 RI', 'GURI INTA CL'],
                    createdAt: '2023-06-10'
                },
                {
                    id: 'user_3',
                    type: 'producer',
                    name: 'Maria Oliveira',
                    document: '987.654.321-00',
                    email: 'maria.oliveira@email.com',
                    password: '123456',
                    phone: '(51) 98888-8888',
                    city: 'Santa Maria',
                    state: 'RS',
                    rating: 4.6,
                    reviewCount: 28,
                    farmArea: 180,
                    avgProduction: 850,
                    varieties: ['IRGA 424', 'BR-IRGA 409'],
                    certifications: ['GlobalGAP'],
                    createdAt: '2024-03-20'
                }
            ];

            // Sample Offers
            const offers = [
                {
                    id: 'offer_1',
                    producerId: 'user_1',
                    variety: 'IRGA 424',
                    type: 'Tipo 1',
                    quantity: 500,
                    unit: 'sacas',
                    humidity: 18.0,
                    price: 88.00,
                    negotiable: true,
                    partialSale: true,
                    city: 'Cachoeira do Sul',
                    state: 'RS',
                    freight: 'FOB',
                    hasTransport: true,
                    description: 'Arroz de excelente qualidade, colheita recente. Disponível para visita técnica.',
                    expiration: '2026-04-30',
                    createdAt: '2026-03-05',
                    status: 'active',
                    views: 245,
                    favorites: 18
                },
                {
                    id: 'offer_2',
                    producerId: 'user_3',
                    variety: 'GURI INTA CL',
                    type: 'Tipo 1',
                    quantity: 300,
                    unit: 'sacas',
                    humidity: 19.5,
                    price: 86.50,
                    negotiable: true,
                    partialSale: false,
                    city: 'Santa Maria',
                    state: 'RS',
                    freight: 'CIF',
                    hasTransport: true,
                    description: 'Lote com umidade controlada, armazenamento climatizado.',
                    expiration: '2026-04-15',
                    createdAt: '2026-03-03',
                    status: 'active',
                    views: 189,
                    favorites: 12
                },
                {
                    id: 'offer_3',
                    producerId: 'user_1',
                    variety: 'BR-IRGA 409',
                    type: 'Tipo 2',
                    quantity: 800,
                    unit: 'sacas',
                    humidity: 20.0,
                    price: 82.00,
                    negotiable: true,
                    partialSale: true,
                    city: 'Cachoeira do Sul',
                    state: 'RS',
                    freight: 'Negociavel',
                    hasTransport: false,
                    description: 'Grande volume disponível, preço especial para compra total.',
                    expiration: '2026-05-10',
                    createdAt: '2026-02-28',
                    status: 'active',
                    views: 312,
                    favorites: 24
                },
                {
                    id: 'offer_4',
                    producerId: 'user_3',
                    variety: 'IRGA 424 RI',
                    type: 'Tipo 1',
                    quantity: 400,
                    unit: 'sacas',
                    humidity: 17.5,
                    price: 90.00,
                    negotiable: false,
                    partialSale: true,
                    city: 'Santa Maria',
                    state: 'RS',
                    freight: 'FOB',
                    hasTransport: false,
                    description: 'Arroz premium, baixa umidade, ideal para beneficiamento imediato.',
                    expiration: '2026-04-20',
                    createdAt: '2026-03-01',
                    status: 'active',
                    views: 167,
                    favorites: 15
                },
                {
                    id: 'offer_5',
                    producerId: 'user_1',
                    variety: 'IRGA 424',
                    type: 'Tipo 1',
                    quantity: 600,
                    unit: 'sacas',
                    humidity: 18.5,
                    price: 87.50,
                    negotiable: true,
                    partialSale: true,
                    city: 'Cachoeira do Sul',
                    state: 'RS',
                    freight: 'FOB',
                    hasTransport: true,
                    description: 'Lote certificado, disponível para retirada imediata.',
                    expiration: '2026-05-05',
                    createdAt: '2026-03-06',
                    status: 'active',
                    views: 134,
                    favorites: 9
                }
            ];

            // Sample Messages
            const messages = [
                {
                    id: 'msg_1',
                    chatId: 'chat_1',
                    senderId: 'user_2',
                    receiverId: 'user_1',
                    offerId: 'offer_1',
                    content: 'Olá João! Vi sua oferta de IRGA 424. Tenho interesse em discutir uma compra.',
                    timestamp: '2026-03-07 09:15:00',
                    read: true
                },
                {
                    id: 'msg_2',
                    chatId: 'chat_1',
                    senderId: 'user_1',
                    receiverId: 'user_2',
                    offerId: 'offer_1',
                    content: 'Bom dia! Seja bem-vindo. Estou à disposição para negociar. Qual quantidade você precisa?',
                    timestamp: '2026-03-07 09:30:00',
                    read: true
                },
                {
                    id: 'msg_3',
                    chatId: 'chat_1',
                    senderId: 'user_2',
                    receiverId: 'user_1',
                    offerId: 'offer_1',
                    content: 'Preciso de 300 sacas inicialmente. Consegue fazer R$ 86,00/saca?',
                    timestamp: '2026-03-07 10:00:00',
                    read: true
                },
                {
                    id: 'msg_4',
                    chatId: 'chat_1',
                    senderId: 'user_1',
                    receiverId: 'user_2',
                    offerId: 'offer_1',
                    content: 'Por 300 sacas consigo fazer R$ 87,00/saca. É um bom preço considerando a qualidade.',
                    timestamp: '2026-03-07 10:15:00',
                    read: false
                }
            ];

            // Sample Chats
            const chats = [
                {
                    id: 'chat_1',
                    participants: ['user_1', 'user_2'],
                    offerId: 'offer_1',
                    lastMessage: 'Por 300 sacas consigo fazer R$ 87,00/saca. É um bom preço considerando a qualidade.',
                    lastMessageTime: '2026-03-07 10:15:00',
                    unreadCount: 1
                }
            ];

            // Save to localStorage
            localStorage.setItem('mercadoArroz_users', JSON.stringify(users));
            localStorage.setItem('mercadoArroz_offers', JSON.stringify(offers));
            localStorage.setItem('mercadoArroz_messages', JSON.stringify(messages));
            localStorage.setItem('mercadoArroz_chats', JSON.stringify(chats));
            localStorage.setItem('mercadoArroz_initialized', 'true');
        }
    }

    // Load user session if exists
    loadUserSession() {
        const sessionUser = localStorage.getItem('mercadoArroz_currentUser');
        if (sessionUser) {
            this.currentUser = JSON.parse(sessionUser);
        }
    }

    // Save user session
    saveUserSession() {
        if (this.currentUser) {
            localStorage.setItem('mercadoArroz_currentUser', JSON.stringify(this.currentUser));
        } else {
            localStorage.removeItem('mercadoArroz_currentUser');
        }
    }

    // Get users
    getUsers() {
        return JSON.parse(localStorage.getItem('mercadoArroz_users') || '[]');
    }

    // Get user by ID
    getUserById(id) {
        const users = this.getUsers();
        return users.find(u => u.id === id);
    }

    // Get offers
    getOffers() {
        return JSON.parse(localStorage.getItem('mercadoArroz_offers') || '[]');
    }

    // Get offer by ID
    getOfferById(id) {
        const offers = this.getOffers();
        return offers.find(o => o.id === id);
    }

    // Add new offer
    addOffer(offerData) {
        const offers = this.getOffers();
        const newOffer = {
            id: 'offer_' + Date.now(),
            producerId: this.currentUser.id,
            ...offerData,
            createdAt: new Date().toISOString().split('T')[0],
            status: 'active',
            views: 0,
            favorites: 0
        };
        offers.push(newOffer);
        localStorage.setItem('mercadoArroz_offers', JSON.stringify(offers));
        return newOffer;
    }

    // Update offer
    updateOffer(offerId, updates) {
        const offers = this.getOffers();
        const offerIndex = offers.findIndex(o => o.id === offerId);
        if (offerIndex !== -1) {
            offers[offerIndex] = { ...offers[offerIndex], ...updates };
            localStorage.setItem('mercadoArroz_offers', JSON.stringify(offers));
            return offers[offerIndex];
        }
        return null;
    }

    // Delete offer
    deleteOffer(offerId) {
        const offers = this.getOffers();
        const updatedOffers = offers.filter(o => o.id !== offerId);
        localStorage.setItem('mercadoArroz_offers', JSON.stringify(updatedOffers));
        return true;
    }

    // Get my offers (current user's offers)
    getMyOffers() {
        if (!this.currentUser || this.currentUser.type !== 'producer') return [];
        const offers = this.getOffers();
        return offers.filter(o => o.producerId === this.currentUser.id);
    }

    // Check expiring offers (12 hours before expiration)
    getExpiringOffers() {
        const myOffers = this.getMyOffers();
        const now = new Date();
        const expiringOffers = [];
        
        myOffers.forEach(offer => {
            if (offer.status === 'active') {
                const expirationDate = new Date(offer.expiration);
                const hoursUntilExpiration = (expirationDate - now) / (1000 * 60 * 60);
                
                if (hoursUntilExpiration > 0 && hoursUntilExpiration <= 12) {
                    expiringOffers.push({
                        ...offer,
                        hoursUntilExpiration: Math.floor(hoursUntilExpiration)
                    });
                }
            }
        });
        
        return expiringOffers;
    }

    // Mark expired offers
    updateExpiredOffers() {
        const offers = this.getOffers();
        const now = new Date();
        let updated = false;
        
        offers.forEach(offer => {
            if (offer.status === 'active') {
                const expirationDate = new Date(offer.expiration);
                if (now > expirationDate) {
                    offer.status = 'expired';
                    updated = true;
                }
            }
        });
        
        if (updated) {
            localStorage.setItem('mercadoArroz_offers', JSON.stringify(offers));
        }
    }

    // Get messages
    getMessages() {
        return JSON.parse(localStorage.getItem('mercadoArroz_messages') || '[]');
    }

    // Get messages by chat ID
    getMessagesByChatId(chatId) {
        const messages = this.getMessages();
        return messages.filter(m => m.chatId === chatId);
    }

    // Add message
    addMessage(chatId, content, receiverId, offerId = null) {
        const messages = this.getMessages();
        const newMessage = {
            id: 'msg_' + Date.now(),
            chatId: chatId,
            senderId: this.currentUser.id,
            receiverId: receiverId,
            offerId: offerId,
            content: content,
            timestamp: new Date().toISOString().replace('T', ' ').substring(0, 19),
            read: false
        };
        messages.push(newMessage);
        localStorage.setItem('mercadoArroz_messages', JSON.stringify(messages));
        
        // Update chat
        this.updateChatLastMessage(chatId, content);
        
        return newMessage;
    }

    // Get chats
    getChats() {
        return JSON.parse(localStorage.getItem('mercadoArroz_chats') || '[]');
    }

    // Get chats for current user
    getUserChats() {
        const chats = this.getChats();
        if (!this.currentUser) return [];
        return chats.filter(c => c.participants.includes(this.currentUser.id));
    }

    // Update chat last message
    updateChatLastMessage(chatId, message) {
        const chats = this.getChats();
        const chat = chats.find(c => c.id === chatId);
        if (chat) {
            chat.lastMessage = message;
            chat.lastMessageTime = new Date().toISOString().replace('T', ' ').substring(0, 19);
            localStorage.setItem('mercadoArroz_chats', JSON.stringify(chats));
        }
    }

    // Initialize app
    initializeApp() {
        this.initializeEventListeners();
        this.initializeNavigation();
        this.renderInitialPage();
        
        // Check expiring offers every hour
        if (this.currentUser && this.currentUser.type === 'producer') {
            this.checkExpiringOffersNotification();
            setInterval(() => {
                this.checkExpiringOffersNotification();
            }, 3600000); // Every hour
        }
    }

    // Check and show notification for expiring offers
    checkExpiringOffersNotification() {
        const expiringOffers = this.getExpiringOffers();
        if (expiringOffers.length > 0) {
            const message = expiringOffers.length === 1 
                ? 'Você tem 1 oferta expirando nas próximas 12 horas!' 
                : `Você tem ${expiringOffers.length} ofertas expirando nas próximas 12 horas!`;
            
            // Show toast notification
            setTimeout(() => {
                this.showToast(message, 5000);
            }, 1000);
        }
    }

    // Initialize event listeners
    initializeEventListeners() {
        // Navigation items
        document.querySelectorAll('.nav-item').forEach(item => {
            item.addEventListener('click', (e) => {
                e.preventDefault();
                const page = item.getAttribute('data-page');
                if (page) {
                    this.navigateTo(page);
                }
            });
        });

        // Tab switching
        document.querySelectorAll('.tab').forEach(tab => {
            tab.addEventListener('click', () => {
                const tabName = tab.getAttribute('data-tab');
                this.switchTab(tabName);
            });
        });

        // Close modals on outside click
        document.querySelectorAll('.modal').forEach(modal => {
            modal.addEventListener('click', (e) => {
                if (e.target === modal) {
                    this.closeModal(modal.id);
                }
            });
        });
    }

    // Initialize navigation
    initializeNavigation() {
        if (this.currentUser) {
            if (this.currentUser.type === 'producer') {
                this.navigateTo('dashboard-producer');
            } else {
                this.navigateTo('dashboard-industry');
            }
        } else {
            this.navigateTo('landing');
        }
    }

    // Render initial page
    renderInitialPage() {
        if (this.currentUser) {
            this.renderDashboard();
        }
    }

    // Navigate to page
    navigateTo(pageName) {
        // Hide all pages
        document.querySelectorAll('.page').forEach(page => {
            page.classList.remove('active');
        });

        // Show target page
        const targetPage = document.getElementById('page-' + pageName);
        if (targetPage) {
            targetPage.classList.add('active');
            this.currentPage = pageName;

            // Update active nav item
            document.querySelectorAll('.nav-item').forEach(item => {
                item.classList.remove('active');
                if (item.getAttribute('data-page') === pageName) {
                    item.classList.add('active');
                }
            });

            // Render page content
            this.renderPageContent(pageName);
        }

        // Close mobile menu if open
        this.closeMobileMenu();
        this.closeSidebar();
    }

    // Render page content
    renderPageContent(pageName) {
        switch(pageName) {
            case 'dashboard-producer':
            case 'dashboard-industry':
                this.renderDashboard();
                break;
            case 'my-offers':
                this.renderMyOffers();
                break;
            case 'search-offers':
                this.renderOffers();
                break;
            case 'map-offers':
                this.renderMap();
                break;
            case 'chat':
                this.renderChat();
                break;
            default:
                break;
        }
    }

    // Render dashboard
    renderDashboard() {
        if (this.currentUser && this.currentUser.type === 'industry') {
            this.renderRecommendedOffers();
        }
        this.renderCharts();
    }

    // Render recommended offers for industry
    renderRecommendedOffers() {
        const container = document.getElementById('recommendedOffers');
        if (!container) return;

        const offers = this.getOffers().slice(0, 3);
        const users = this.getUsers();

        container.innerHTML = offers.map(offer => {
            const producer = users.find(u => u.id === offer.producerId);
            return this.renderOfferCard(offer, producer);
        }).join('');

        // Add click listeners
        container.querySelectorAll('.offer-card').forEach((card, index) => {
            card.addEventListener('click', () => {
                this.showOfferDetail(offers[index]);
            });
        });
    }

    // Render offer card
    renderOfferCard(offer, producer) {
        return `
            <div class="offer-card" data-offer-id="${offer.id}">
                <img src="https://via.placeholder.com/400x200/5F6C37/FEFADF?text=${encodeURIComponent(offer.variety)}" 
                     alt="${offer.variety}" 
                     class="offer-image">
                <div class="offer-content">
                    <div class="offer-header">
                        <h3 class="offer-title">${offer.variety}</h3>
                        <span class="offer-badge">${offer.type}</span>
                    </div>
                    <p class="offer-price">
                        R$ ${offer.price.toFixed(2)}<span>/saca</span>
                    </p>
                    <div class="offer-details">
                        <div class="offer-detail">
                            <i class="fas fa-box"></i>
                            <span>${offer.quantity} ${offer.unit}</span>
                        </div>
                        <div class="offer-detail">
                            <i class="fas fa-tint"></i>
                            <span>Umidade: ${offer.humidity}%</span>
                        </div>
                        <div class="offer-detail">
                            <i class="fas fa-map-marker-alt"></i>
                            <span>${offer.city}, ${offer.state}</span>
                        </div>
                        <div class="offer-detail">
                            <i class="fas fa-truck"></i>
                            <span>${offer.freight}</span>
                        </div>
                    </div>
                    <div class="offer-footer">
                        <div class="offer-producer">
                            <div class="user-avatar small">
                                <i class="fas fa-user"></i>
                            </div>
                            <div class="producer-info">
                                <span class="producer-name">${producer ? producer.name : 'Produtor'}</span>
                                <span class="producer-rating">
                                    <i class="fas fa-star"></i> ${producer ? producer.rating : '0.0'}
                                </span>
                            </div>
                        </div>
                        <button class="btn-favorite" onclick="event.stopPropagation(); app.toggleFavorite('${offer.id}')">
                            <i class="far fa-heart"></i>
                        </button>
                    </div>
                </div>
            </div>
        `;
    }

    // Render all offers
    renderOffers() {
        const container = document.getElementById('offersGrid');
        if (!container) return;

        const offers = this.getOffers();
        const users = this.getUsers();

        container.innerHTML = offers.map(offer => {
            const producer = users.find(u => u.id === offer.producerId);
            return this.renderOfferCard(offer, producer);
        }).join('');

        // Add click listeners
        container.querySelectorAll('.offer-card').forEach(card => {
            const offerId = card.getAttribute('data-offer-id');
            const offer = offers.find(o => o.id === offerId);
            if (offer) {
                card.addEventListener('click', () => {
                    this.showOfferDetail(offer);
                });
            }
        });
    }

    // Render my offers page
    renderMyOffers(filter = 'all') {
        // Update expired offers first
        this.updateExpiredOffers();
        
        const myOffers = this.getMyOffers();
        let filteredOffers = myOffers;

        // Apply filter
        if (filter === 'active') {
            filteredOffers = myOffers.filter(o => o.status === 'active');
        } else if (filter === 'expiring') {
            const expiringOffers = this.getExpiringOffers();
            filteredOffers = expiringOffers;
        } else if (filter === 'expired') {
            filteredOffers = myOffers.filter(o => o.status === 'expired');
        }

        // Update stats
        this.updateMyOffersStats(myOffers);

        // Show expiring alerts
        this.showExpiringAlertsMyOffers();

        // Render offers grid
        const container = document.getElementById('myOffersGrid');
        const emptyState = document.getElementById('myOffersEmptyState');
        
        if (!container || !emptyState) return;

        if (filteredOffers.length === 0) {
            container.style.display = 'none';
            emptyState.style.display = 'block';
        } else {
            container.style.display = 'grid';
            emptyState.style.display = 'none';
            
            container.innerHTML = filteredOffers.map(offer => {
                return this.renderMyOfferCard(offer);
            }).join('');
        }

        // Update filter buttons
        ['All', 'Active', 'Expiring', 'Expired'].forEach(f => {
            const btn = document.getElementById('filter' + f);
            if (btn) {
                if (f.toLowerCase() === filter) {
                    btn.style.backgroundColor = 'var(--color-primary)';
                    btn.style.color = 'var(--color-white)';
                } else {
                    btn.style.backgroundColor = 'var(--color-white)';
                    btn.style.color = 'var(--color-primary)';
                }
            }
        });
    }

    // Update my offers stats
    updateMyOffersStats(offers) {
        const activeCount = offers.filter(o => o.status === 'active').length;
        const totalViews = offers.reduce((sum, o) => sum + (o.views || 0), 0);
        const totalFavorites = offers.reduce((sum, o) => sum + (o.favorites || 0), 0);
        const expiringCount = this.getExpiringOffers().length;

        const activeEl = document.getElementById('myOffersActiveCount');
        const viewsEl = document.getElementById('myOffersTotalViews');
        const favoritesEl = document.getElementById('myOffersTotalFavorites');
        const expiringEl = document.getElementById('myOffersExpiringCount');

        if (activeEl) activeEl.textContent = activeCount;
        if (viewsEl) viewsEl.textContent = totalViews;
        if (favoritesEl) favoritesEl.textContent = totalFavorites;
        if (expiringEl) expiringEl.textContent = expiringCount;
    }

    // Show expiring alerts on my offers page
    showExpiringAlertsMyOffers() {
        const expiringOffers = this.getExpiringOffers();
        const alertContainer = document.getElementById('expiringOffersAlert');
        const contentContainer = document.getElementById('expiringOffersContent');

        if (!alertContainer || !contentContainer) return;

        if (expiringOffers.length > 0) {
            alertContainer.style.display = 'flex';
            contentContainer.innerHTML = expiringOffers.map(offer => {
                const hoursText = offer.hoursUntilExpiration === 1 ? '1 hora' : `${offer.hoursUntilExpiration} horas`;
                return `
                    <div style="padding: 0.75rem 0; border-bottom: 1px solid rgba(0,0,0,0.1);">
                        <strong>${offer.variety} - ${offer.type}</strong> 
                        expira em <strong style="color: #FF9800;">${hoursText}</strong>
                        <button onclick="app.openManageOfferModal('${offer.id}')" 
                                style="margin-left: 1rem; padding: 0.25rem 0.75rem; background-color: #273617; color: white; border: none; border-radius: 6px; cursor: pointer; font-size: 0.813rem;">
                            <i class="fas fa-edit"></i> Gerenciar
                        </button>
                    </div>
                `;
            }).join('');
        } else {
            alertContainer.style.display = 'none';
        }
    }

    // Render my offer card
    renderMyOfferCard(offer) {
        const now = new Date();
        const expirationDate = new Date(offer.expiration);
        const daysUntilExpiration = Math.ceil((expirationDate - now) / (1000 * 60 * 60 * 24));
        
        let statusBadge = '';
        let statusClass = '';
        
        if (offer.status === 'expired') {
            statusBadge = '<span class="offer-badge" style="background-color: var(--color-error);">Expirada</span>';
            statusClass = 'opacity: 0.6;';
        } else if (daysUntilExpiration <= 1) {
            statusBadge = '<span class="offer-badge" style="background-color: var(--color-error);">Expira hoje!</span>';
        } else if (daysUntilExpiration <= 3) {
            statusBadge = '<span class="offer-badge" style="background-color: var(--color-warning);">Expira em ' + daysUntilExpiration + ' dias</span>';
        } else {
            statusBadge = '<span class="offer-badge" style="background-color: var(--color-success);">Ativa</span>';
        }

        return `
            <div class="offer-card" style="${statusClass}">
                <img src="https://via.placeholder.com/400x200/5F6C37/FEFADF?text=${encodeURIComponent(offer.variety)}" 
                     alt="${offer.variety}" 
                     class="offer-image">
                <div class="offer-content">
                    <div class="offer-header">
                        <h3 class="offer-title">${offer.variety}</h3>
                        ${statusBadge}
                    </div>
                    <p class="offer-price">
                        R$ ${offer.price.toFixed(2)}<span>/saca</span>
                    </p>
                    <div class="offer-details">
                        <div class="offer-detail">
                            <i class="fas fa-box"></i>
                            <span>${offer.quantity} ${offer.unit}</span>
                        </div>
                        <div class="offer-detail">
                            <i class="fas fa-tint"></i>
                            <span>Umidade: ${offer.humidity}%</span>
                        </div>
                        <div class="offer-detail">
                            <i class="fas fa-eye"></i>
                            <span>${offer.views || 0} visualizações</span>
                        </div>
                        <div class="offer-detail">
                            <i class="fas fa-calendar"></i>
                            <span>Expira: ${new Date(offer.expiration).toLocaleDateString('pt-BR')}</span>
                        </div>
                    </div>
                    <div class="offer-footer" style="border-top: 1px solid var(--color-gray-200); padding-top: 1rem; margin-top: 1rem;">
                        <button class="btn-secondary btn-sm" onclick="event.stopPropagation(); app.openManageOfferModal('${offer.id}')" style="flex: 1;">
                            <i class="fas fa-cog"></i> Gerenciar
                        </button>
                        <button class="btn-primary btn-sm" onclick="event.stopPropagation(); app.showOfferDetail(app.getOfferById('${offer.id}'))" style="flex: 1; margin-left: 0.5rem;">
                            <i class="fas fa-eye"></i> Ver Detalhes
                        </button>
                    </div>
                </div>
            </div>
        `;
    }

    // Filter my offers
    filterMyOffers(filter) {
        this.renderMyOffers(filter);
    }

    // Open manage offer modal
    openManageOfferModal(offerId) {
        const offer = this.getOfferById(offerId);
        if (!offer) return;

        const modal = document.getElementById('manageOfferModal');
        const content = document.getElementById('manageOfferContent');

        const now = new Date();
        const expirationDate = new Date(offer.expiration);
        const daysUntilExpiration = Math.ceil((expirationDate - now) / (1000 * 60 * 60 * 24));

        content.innerHTML = `
            <div style="margin-bottom: 1.5rem;">
                <h4 style="font-size: 1.125rem; color: var(--color-primary); margin-bottom: 0.5rem;">${offer.variety} - ${offer.type}</h4>
                <div style="display: flex; gap: 1rem; font-size: 0.875rem; color: var(--color-gray-600);">
                    <span><i class="fas fa-box"></i> ${offer.quantity} ${offer.unit}</span>
                    <span><i class="fas fa-dollar-sign"></i> R$ ${offer.price.toFixed(2)}/saca</span>
                    <span><i class="fas fa-calendar"></i> Expira em ${daysUntilExpiration} dias</span>
                </div>
            </div>

            <div style="display: flex; flex-direction: column; gap: 1rem;">
                <button class="btn-secondary btn-block" onclick="app.extendOfferExpiration('${offer.id}')">
                    <i class="fas fa-calendar-plus"></i> Estender Validade (+7 dias)
                </button>
                <button class="btn-secondary btn-block" onclick="app.showEditOfferForm('${offer.id}')">
                    <i class="fas fa-edit"></i> Editar Preço/Quantidade
                </button>
                ${offer.status === 'active' ? `
                    <button class="btn-secondary btn-block" onclick="app.pauseOffer('${offer.id}')">
                        <i class="fas fa-pause"></i> Pausar Oferta
                    </button>
                ` : `
                    <button class="btn-primary btn-block" onclick="app.reactivateOffer('${offer.id}')">
                        <i class="fas fa-play"></i> Reativar Oferta
                    </button>
                `}
                <button class="btn-secondary btn-block" style="color: var(--color-error); border-color: var(--color-error);" onclick="app.confirmDeleteOffer('${offer.id}')">
                    <i class="fas fa-trash"></i> Excluir Oferta
                </button>
            </div>
        `;

        modal.classList.add('active');
    }

    // Extend offer expiration
    extendOfferExpiration(offerId) {
        const offer = this.getOfferById(offerId);
        if (!offer) return;

        const currentExpiration = new Date(offer.expiration);
        currentExpiration.setDate(currentExpiration.getDate() + 7);
        const newExpiration = currentExpiration.toISOString().split('T')[0];

        this.updateOffer(offerId, { expiration: newExpiration });
        this.closeModal('manageOfferModal');
        this.showToast('Validade estendida por mais 7 dias!');
        this.renderMyOffers();
    }

    // Pause offer
    pauseOffer(offerId) {
        this.updateOffer(offerId, { status: 'paused' });
        this.closeModal('manageOfferModal');
        this.showToast('Oferta pausada com sucesso!');
        this.renderMyOffers();
    }

    // Reactivate offer
    reactivateOffer(offerId) {
        this.updateOffer(offerId, { status: 'active' });
        this.closeModal('manageOfferModal');
        this.showToast('Oferta reativada com sucesso!');
        this.renderMyOffers();
    }

    // Confirm delete offer
    confirmDeleteOffer(offerId) {
        if (confirm('Tem certeza que deseja excluir esta oferta? Esta ação não pode ser desfeita.')) {
            this.deleteOffer(offerId);
            this.closeModal('manageOfferModal');
            this.showToast('Oferta excluída com sucesso!');
            this.renderMyOffers();
        }
    }

    // Show offer detail modal
    showOfferDetail(offer) {
        const modal = document.getElementById('offerDetailModal');
        const content = document.getElementById('offerDetailContent');
        const users = this.getUsers();
        const producer = users.find(u => u.id === offer.producerId);

        content.innerHTML = `
            <div class="offer-detail-header">
                <img src="https://via.placeholder.com/800x400/5F6C37/FEFADF?text=${encodeURIComponent(offer.variety)}" 
                     alt="${offer.variety}" 
                     style="width: 100%; height: 300px; object-fit: cover; border-radius: 12px; margin-bottom: 1.5rem;">
                <div style="display: flex; justify-content: space-between; align-items: start;">
                    <div>
                        <h2 style="font-size: 2rem; color: var(--color-primary); margin-bottom: 0.5rem;">${offer.variety} - ${offer.type}</h2>
                        <p style="color: var(--color-gray-600);">Oferta #${offer.id}</p>
                    </div>
                    <div style="text-align: right;">
                        <p style="font-size: 2.5rem; font-weight: 800; color: var(--color-accent);">R$ ${offer.price.toFixed(2)}</p>
                        <p style="color: var(--color-gray-600);">por saca de 50kg</p>
                    </div>
                </div>
            </div>
            
            <div style="display: grid; grid-template-columns: repeat(auto-fit, minmax(200px, 1fr)); gap: 1.5rem; margin: 2rem 0; padding: 2rem; background-color: var(--color-gray-50); border-radius: 12px;">
                <div>
                    <p style="color: var(--color-gray-600); font-size: 0.875rem; margin-bottom: 0.25rem;">Quantidade</p>
                    <p style="font-size: 1.25rem; font-weight: 700; color: var(--color-primary);">${offer.quantity} ${offer.unit}</p>
                </div>
                <div>
                    <p style="color: var(--color-gray-600); font-size: 0.875rem; margin-bottom: 0.25rem;">Umidade</p>
                    <p style="font-size: 1.25rem; font-weight: 700; color: var(--color-primary);">${offer.humidity}%</p>
                </div>
                <div>
                    <p style="color: var(--color-gray-600); font-size: 0.875rem; margin-bottom: 0.25rem;">Localização</p>
                    <p style="font-size: 1.25rem; font-weight: 700; color: var(--color-primary);">${offer.city}, ${offer.state}</p>
                </div>
                <div>
                    <p style="color: var(--color-gray-600); font-size: 0.875rem; margin-bottom: 0.25rem;">Frete</p>
                    <p style="font-size: 1.25rem; font-weight: 700; color: var(--color-primary);">${offer.freight}</p>
                </div>
            </div>

            <div style="margin: 2rem 0;">
                <h3 style="font-size: 1.25rem; font-weight: 600; color: var(--color-primary); margin-bottom: 1rem;">Descrição</h3>
                <p style="line-height: 1.8; color: var(--color-gray-700);">${offer.description}</p>
            </div>

            <div style="margin: 2rem 0;">
                <h3 style="font-size: 1.25rem; font-weight: 600; color: var(--color-primary); margin-bottom: 1rem;">Informações Adicionais</h3>
                <div style="display: flex; flex-direction: column; gap: 0.75rem;">
                    <div style="display: flex; align-items: center; gap: 0.5rem;">
                        <i class="fas fa-check-circle" style="color: var(--color-success);"></i>
                        <span>${offer.negotiable ? 'Preço negociável' : 'Preço fixo'}</span>
                    </div>
                    <div style="display: flex; align-items: center; gap: 0.5rem;">
                        <i class="fas fa-check-circle" style="color: var(--color-success);"></i>
                        <span>${offer.partialSale ? 'Aceita venda parcial' : 'Venda total apenas'}</span>
                    </div>
                    <div style="display: flex; align-items: center; gap: 0.5rem;">
                        <i class="fas fa-${offer.hasTransport ? 'check-circle' : 'times-circle'}" style="color: var(--color-${offer.hasTransport ? 'success' : 'error'});"></i>
                        <span>${offer.hasTransport ? 'Possui transporte próprio' : 'Sem transporte próprio'}</span>
                    </div>
                    <div style="display: flex; align-items: center; gap: 0.5rem;">
                        <i class="fas fa-calendar" style="color: var(--color-accent);"></i>
                        <span>Válido até: ${new Date(offer.expiration).toLocaleDateString('pt-BR')}</span>
                    </div>
                </div>
            </div>

            <div style="margin: 2rem 0; padding: 1.5rem; background-color: var(--color-background); border-radius: 12px;">
                <h3 style="font-size: 1.25rem; font-weight: 600; color: var(--color-primary); margin-bottom: 1rem;">Sobre o Produtor</h3>
                <div style="display: flex; align-items: center; gap: 1rem; margin-bottom: 1rem;">
                    <div class="user-avatar large">
                        <i class="fas fa-user"></i>
                    </div>
                    <div>
                        <h4 style="font-size: 1.125rem; font-weight: 600; color: var(--color-gray-900); margin-bottom: 0.25rem;">${producer ? producer.name : 'Produtor'}</h4>
                        <div style="display: flex; align-items: center; gap: 0.5rem;">
                            <i class="fas fa-star" style="color: var(--color-accent);"></i>
                            <span style="font-weight: 600;">${producer ? producer.rating : '0.0'}</span>
                            <span style="color: var(--color-gray-600);">(${producer ? producer.reviewCount : 0} avaliações)</span>
                        </div>
                    </div>
                </div>
                ${producer && producer.type === 'producer' ? `
                    <div style="display: grid; grid-template-columns: 1fr 1fr; gap: 1rem; font-size: 0.875rem;">
                        <div>
                            <p style="color: var(--color-gray-600);">Área plantada</p>
                            <p style="font-weight: 600; color: var(--color-gray-900);">${producer.farmArea} hectares</p>
                        </div>
                        <div>
                            <p style="color: var(--color-gray-600);">Produção média</p>
                            <p style="font-weight: 600; color: var(--color-gray-900);">${producer.avgProduction} toneladas/ano</p>
                        </div>
                    </div>
                ` : ''}
            </div>

            <div style="display: flex; gap: 1rem; margin-top: 2rem;">
                <button class="btn-secondary" style="flex: 1;" onclick="app.closeModal('offerDetailModal')">
                    <i class="fas fa-times"></i> Fechar
                </button>
                ${this.currentUser && this.currentUser.type === 'industry' ? `
                    <button class="btn-primary" style="flex: 2;" onclick="app.openProposalModal('${offer.id}')">
                        <i class="fas fa-file-alt"></i> Enviar Proposta
                    </button>
                ` : ''}
            </div>
        `;

        modal.classList.add('active');
    }

    // Close modal
    closeModal(modalId) {
        const modal = document.getElementById(modalId);
        if (modal) {
            modal.classList.remove('active');
        }
    }

    // Open proposal modal
    openProposalModal(offerId) {
        this.closeModal('offerDetailModal');
        const modal = document.getElementById('proposalModal');
        modal.setAttribute('data-offer-id', offerId);
        modal.classList.add('active');
    }

    // Toggle favorite
    toggleFavorite(offerId) {
        this.showToast('Funcionalidade em desenvolvimento');
    }

    // Render charts
    renderCharts() {
        setTimeout(() => {
            this.renderSalesChart();
            this.renderPriceChart();
        }, 100);
    }

    // Render sales chart
    renderSalesChart() {
        const canvas = document.getElementById('salesChart');
        if (!canvas) return;

        const ctx = canvas.getContext('2d');
        new Chart(ctx, {
            type: 'bar',
            data: {
                labels: ['Out', 'Nov', 'Dez', 'Jan', 'Fev', 'Mar'],
                datasets: [{
                    label: 'Vendas (toneladas)',
                    data: [120, 150, 180, 165, 190, 210],
                    backgroundColor: '#DCA25D',
                    borderRadius: 8
                }]
            },
            options: {
                responsive: true,
                maintainAspectRatio: false,
                plugins: {
                    legend: {
                        display: false
                    }
                },
                scales: {
                    y: {
                        beginAtZero: true
                    }
                }
            }
        });
    }

    // Render price chart
    renderPriceChart() {
        const canvas = document.getElementById('priceChart');
        if (!canvas) return;

        const ctx = canvas.getContext('2d');
        new Chart(ctx, {
            type: 'line',
            data: {
                labels: ['Semana 1', 'Semana 2', 'Semana 3', 'Semana 4'],
                datasets: [{
                    label: 'Preço Médio (R$/saca)',
                    data: [84.50, 85.00, 86.20, 88.00],
                    borderColor: '#273617',
                    backgroundColor: 'rgba(39, 54, 23, 0.1)',
                    tension: 0.4,
                    fill: true
                }]
            },
            options: {
                responsive: true,
                maintainAspectRatio: false,
                plugins: {
                    legend: {
                        display: false
                    }
                },
                scales: {
                    y: {
                        beginAtZero: false,
                        min: 80,
                        max: 90
                    }
                }
            }
        });
    }

    // Render map
    renderMap() {
        setTimeout(() => {
            const mapElement = document.getElementById('map');
            if (!mapElement || mapElement.classList.contains('map-initialized')) return;

            // Initialize Leaflet map
            const map = L.map('map').setView([-30.0346, -51.2177], 7);

            L.tileLayer('https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png', {
                attribution: '© OpenStreetMap contributors'
            }).addTo(map);

            // Add markers for offers
            const offers = this.getOffers();
            const cities = {
                'Cachoeira do Sul': [-30.0346, -52.8934],
                'Santa Maria': [-29.6842, -53.8069],
                'Porto Alegre': [-30.0346, -51.2177]
            };

            offers.forEach(offer => {
                const coords = cities[offer.city];
                if (coords) {
                    const markerColor = offer.type === 'Tipo 1' && offer.price < 85 ? 'green' :
                                      offer.type === 'Tipo 1' ? 'yellow' : 'blue';
                    
                    L.circleMarker(coords, {
                        radius: 10,
                        fillColor: markerColor === 'green' ? '#4CAF50' : 
                                 markerColor === 'yellow' ? '#DCA25D' : '#2196F3',
                        color: '#fff',
                        weight: 2,
                        opacity: 1,
                        fillOpacity: 0.8
                    }).addTo(map)
                    .bindPopup(`
                        <div style="font-family: Inter, sans-serif;">
                            <h4 style="margin: 0 0 0.5rem 0; color: #273617;">${offer.variety}</h4>
                            <p style="margin: 0; font-size: 0.875rem;"><strong>R$ ${offer.price.toFixed(2)}/saca</strong></p>
                            <p style="margin: 0.25rem 0; font-size: 0.813rem; color: #666;">${offer.quantity} ${offer.unit} - ${offer.type}</p>
                            <button onclick="app.showOfferDetail(app.getOfferById('${offer.id}'))" 
                                    style="margin-top: 0.5rem; padding: 0.5rem 1rem; background-color: #273617; color: white; border: none; border-radius: 6px; cursor: pointer; font-size: 0.813rem;">
                                Ver Detalhes
                            </button>
                        </div>
                    `);
                }
            });

            mapElement.classList.add('map-initialized');
        }, 100);
    }

    // Render chat
    renderChat() {
        this.renderChatList();
        if (this.currentChatId) {
            this.renderChatMessages(this.currentChatId);
        }
    }

    // Render chat list
    renderChatList() {
        const container = document.getElementById('chatList');
        if (!container) return;

        const chats = this.getUserChats();
        const users = this.getUsers();

        if (chats.length === 0) {
            container.innerHTML = `
                <div style="padding: 2rem; text-align: center; color: var(--color-gray-500);">
                    <i class="fas fa-comments" style="font-size: 3rem; margin-bottom: 1rem; opacity: 0.3;"></i>
                    <p>Nenhuma conversa ainda</p>
                </div>
            `;
            return;
        }

        container.innerHTML = chats.map(chat => {
            const otherUserId = chat.participants.find(id => id !== this.currentUser.id);
            const otherUser = users.find(u => u.id === otherUserId);
            
            return `
                <div class="chat-item ${chat.id === this.currentChatId ? 'active' : ''}" 
                     onclick="app.selectChat('${chat.id}')">
                    <div class="chat-item-header">
                        <span class="chat-item-name">${otherUser ? otherUser.name : 'Usuário'}</span>
                        <span class="chat-item-time">${this.formatTime(chat.lastMessageTime)}</span>
                    </div>
                    <p class="chat-item-preview ${chat.unreadCount > 0 ? 'unread' : ''}">
                        ${chat.lastMessage}
                    </p>
                </div>
            `;
        }).join('');

        // Auto-select first chat if none selected
        if (!this.currentChatId && chats.length > 0) {
            this.selectChat(chats[0].id);
        }
    }

    // Select chat
    selectChat(chatId) {
        this.currentChatId = chatId;
        this.renderChatList();
        this.renderChatMessages(chatId);
    }

    // Render chat messages
    renderChatMessages(chatId) {
        const container = document.getElementById('chatMessages');
        if (!container) return;

        const messages = this.getMessagesByChatId(chatId);
        const users = this.getUsers();

        container.innerHTML = messages.map(msg => {
            const sender = users.find(u => u.id === msg.senderId);
            const isSent = msg.senderId === this.currentUser.id;

            return `
                <div class="message ${isSent ? 'sent' : ''}">
                    <div class="message-avatar">
                        <i class="fas fa-${sender && sender.type === 'industry' ? 'building' : 'user'}"></i>
                    </div>
                    <div class="message-content">
                        <div class="message-header">
                            <span class="message-name">${sender ? sender.name : 'Usuário'}</span>
                            <span class="message-time">${this.formatTime(msg.timestamp)}</span>
                        </div>
                        <div class="message-bubble">
                            ${msg.content}
                        </div>
                    </div>
                </div>
            `;
        }).join('');

        // Scroll to bottom
        container.scrollTop = container.scrollHeight;
    }

    // Send message
    sendMessage() {
        const input = document.getElementById('messageInput');
        if (!input || !this.currentChatId) return;

        const content = input.value.trim();
        if (!content) return;

        const chats = this.getChats();
        const chat = chats.find(c => c.id === this.currentChatId);
        if (!chat) return;

        const receiverId = chat.participants.find(id => id !== this.currentUser.id);
        this.addMessage(this.currentChatId, content, receiverId, chat.offerId);

        input.value = '';
        this.renderChatMessages(this.currentChatId);
        this.renderChatList();
    }

    // Format time
    formatTime(timestamp) {
        const date = new Date(timestamp);
        const now = new Date();
        const diff = now - date;
        const hours = Math.floor(diff / (1000 * 60 * 60));
        const days = Math.floor(diff / (1000 * 60 * 60 * 24));

        if (hours < 1) return 'Agora';
        if (hours < 24) return `Há ${hours}h`;
        if (days < 7) return `Há ${days}d`;
        return date.toLocaleDateString('pt-BR');
    }

    // Show toast notification
    showToast(message, duration = 3000) {
        const toast = document.getElementById('toast');
        const messageEl = document.getElementById('toastMessage');
        
        if (toast && messageEl) {
            messageEl.textContent = message;
            toast.classList.add('show');
            
            setTimeout(() => {
                toast.classList.remove('show');
            }, duration);
        }
    }

    // Toggle sidebar
    toggleSidebar() {
        const sidebar = document.querySelector('.sidebar');
        if (sidebar) {
            sidebar.classList.toggle('active');
        }
    }

    // Close sidebar
    closeSidebar() {
        const sidebar = document.querySelector('.sidebar');
        if (sidebar) {
            sidebar.classList.remove('active');
        }
    }

    // Toggle mobile menu
    toggleMobileMenu() {
        const menu = document.getElementById('mobileMenu');
        if (menu) {
            menu.classList.toggle('active');
        }
    }

    // Close mobile menu
    closeMobileMenu() {
        const menu = document.getElementById('mobileMenu');
        if (menu) {
            menu.classList.remove('active');
        }
    }

    // Toggle filters
    toggleFilters() {
        const panel = document.getElementById('filtersPanel');
        if (panel) {
            panel.classList.toggle('active');
        }
    }

    // Switch tab
    switchTab(tabName) {
        // Update tabs
        document.querySelectorAll('.tab').forEach(tab => {
            tab.classList.remove('active');
            if (tab.getAttribute('data-tab') === tabName) {
                tab.classList.add('active');
            }
        });

        // Update tab contents
        document.querySelectorAll('.tab-content').forEach(content => {
            content.classList.remove('active');
        });
        
        const targetContent = document.getElementById('tab-' + tabName);
        if (targetContent) {
            targetContent.classList.add('active');
        }
    }

    // Logout
    logout() {
        this.currentUser = null;
        this.saveUserSession();
        this.navigateTo('landing');
        this.showToast('Logout realizado com sucesso');
    }
}

// ============================================
// FORM HANDLERS
// ============================================

// Handle login
function handleLogin(event) {
    event.preventDefault();
    
    const email = document.getElementById('loginEmail').value;
    const password = document.getElementById('loginPassword').value;

    const users = JSON.parse(localStorage.getItem('mercadoArroz_users') || '[]');
    const user = users.find(u => 
        (u.email === email || u.document === email) && u.password === password
    );

    if (user) {
        app.currentUser = user;
        app.saveUserSession();
        
        if (user.type === 'producer') {
            app.navigateTo('dashboard-producer');
        } else {
            app.navigateTo('dashboard-industry');
        }
        
        app.showToast('Login realizado com sucesso!');
    } else {
        app.showToast('Email ou senha incorretos', 3000);
    }
}

// Handle register
function handleRegister(event) {
    event.preventDefault();
    
    const userType = document.querySelector('input[name="userType"]:checked').value;
    const name = document.getElementById('registerName').value;
    const document = document.getElementById('registerDocument').value;
    const email = document.getElementById('registerEmail').value;
    const phone = document.getElementById('registerPhone').value;
    const password = document.getElementById('registerPassword').value;

    const users = JSON.parse(localStorage.getItem('mercadoArroz_users') || '[]');
    
    // Check if email already exists
    if (users.find(u => u.email === email)) {
        app.showToast('Este e-mail já está cadastrado');
        return;
    }

    const newUser = {
        id: 'user_' + Date.now(),
        type: userType,
        name: name,
        document: document,
        email: email,
        phone: phone,
        password: password,
        city: 'Porto Alegre',
        state: 'RS',
        rating: 0,
        reviewCount: 0,
        createdAt: new Date().toISOString().split('T')[0]
    };

    users.push(newUser);
    localStorage.setItem('mercadoArroz_users', JSON.stringify(users));

    app.currentUser = newUser;
    app.saveUserSession();

    if (userType === 'producer') {
        app.navigateTo('dashboard-producer');
    } else {
        app.navigateTo('dashboard-industry');
    }

    app.showToast('Cadastro realizado com sucesso!');
}

// Handle create offer
function handleCreateOffer(event) {
    event.preventDefault();

    const offerData = {
        variety: document.getElementById('offerVariety').value,
        type: document.getElementById('offerType').value,
        quantity: parseInt(document.getElementById('offerQuantity').value),
        unit: document.getElementById('offerUnit').value,
        humidity: parseFloat(document.getElementById('offerHumidity').value),
        price: parseFloat(document.getElementById('offerPrice').value),
        negotiable: document.getElementById('offerNegotiable').value === 'sim',
        partialSale: document.getElementById('offerPartialSale').checked,
        city: document.getElementById('offerCity').value,
        state: document.getElementById('offerState').value,
        freight: document.getElementById('offerFreight').value,
        hasTransport: document.getElementById('offerHasTransport').checked,
        description: document.getElementById('offerDescription').value,
        expiration: document.getElementById('offerExpiration').value
    };

    app.addOffer(offerData);
    app.showToast('Oferta publicada com sucesso!');
    
    // Clear form
    document.getElementById('createOfferForm').reset();
    
    app.navigateTo('my-offers');
}

// Handle send proposal
function handleSendProposal(event) {
    event.preventDefault();

    const modal = document.getElementById('proposalModal');
    const offerId = modal.getAttribute('data-offer-id');
    
    app.showToast('Proposta enviada com sucesso!');
    app.closeModal('proposalModal');
}

// Handle logout
function handleLogout() {
    if (confirm('Deseja realmente sair?')) {
        app.logout();
    }
}

// Navigate to page (global function)
function navigateTo(page) {
    app.navigateTo(page);
}

// Navigate to dashboard based on user type
function navigateToDashboard() {
    if (app.currentUser) {
        if (app.currentUser.type === 'producer') {
            app.navigateTo('dashboard-producer');
        } else {
            app.navigateTo('dashboard-industry');
        }
    }
}

// Toggle sidebar
function toggleSidebar() {
    app.toggleSidebar();
}

// Toggle mobile menu
function toggleMobileMenu() {
    app.toggleMobileMenu();
}

// Toggle filters
function toggleFilters() {
    app.toggleFilters();
}

// Clear filters
function clearFilters() {
    document.getElementById('filterState').value = '';
    document.getElementById('filterVariety').value = '';
    document.getElementById('filterType').value = '';
    document.getElementById('filterPriceMin').value = '';
    document.getElementById('filterPriceMax').value = '';
    document.getElementById('filterQuantityMin').value = '';
    document.getElementById('filterHumidity').value = '';
}

// Apply filters
function applyFilters() {
    app.showToast('Filtros aplicados');
    toggleFilters();
}

// Close modal
function closeModal(modalId) {
    app.closeModal(modalId);
}

// Toggle user menu
function toggleUserMenu() {
    app.showToast('Menu do usuário');
}

// Toggle notifications
function toggleNotifications() {
    app.showToast('Notificações');
}

// Scroll to section
function scrollToSection(sectionId) {
    const element = document.getElementById(sectionId);
    if (element) {
        element.scrollIntoView({ behavior: 'smooth' });
    }
    app.closeMobileMenu();
}

// Send message
function sendMessage() {
    app.sendMessage();
}

// Handle message keypress
function handleMessageKeypress(event) {
    if (event.key === 'Enter' && !event.shiftKey) {
        event.preventDefault();
        sendMessage();
    }
}

// ============================================
// INITIALIZATION
// ============================================

// Initialize app when DOM is loaded
let app;

document.addEventListener('DOMContentLoaded', () => {
    app = new MercadoArrozApp();
    console.log('Mercado Arroz App initialized');
});