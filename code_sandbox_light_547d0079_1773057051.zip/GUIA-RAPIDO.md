# 🚀 Guia Rápido - Mercado Arroz

## Como Testar o Aplicativo

### 1️⃣ Abrir o Aplicativo

**Opção A - Diretamente no Navegador:**
- Localize o arquivo `index.html`
- Dê duplo clique ou arraste para o navegador
- Pronto! O app está rodando

**Opção B - Com Servidor Local (Recomendado):**
```bash
# Python 3
python -m http.server 8000

# Node.js
npx http-server -p 8000

# Acesse: http://localhost:8000
```

---

## 2️⃣ Fluxo de Teste Completo

### Cenário 1: Como Produtor 🧑‍🌾

#### Passo 1: Fazer Login
1. Na landing page, clique em **"Entrar"**
2. Use as credenciais:
   - **E-mail:** `joao.silva@email.com`
   - **Senha:** `123456`
3. Clique em **"Entrar"**

#### Passo 2: Explorar o Dashboard
- ✅ Veja suas estatísticas (ofertas ativas, negociações, vendas)
- ✅ Analise os gráficos de vendas e preços
- ✅ Verifique as atividades recentes

#### Passo 3: Criar uma Nova Oferta
1. No menu lateral, clique em **"Nova Oferta"**
2. Preencha o formulário:
   - **Variedade:** IRGA 424
   - **Tipo:** Tipo 1
   - **Quantidade:** 300 sacas
   - **Umidade:** 18%
   - **Preço:** R$ 87,00
   - **Cidade:** Sua cidade
   - **Frete:** FOB
3. Clique em **"Publicar Oferta"**
4. ✅ Você verá uma notificação de sucesso!

#### Passo 4: Ver Mensagens
1. Clique em **"Mensagens"** no menu
2. ✅ Veja conversas com indústrias interessadas
3. Clique em uma conversa para ver o histórico
4. Digite uma mensagem e envie

#### Passo 5: Ver seu Perfil
1. Clique em **"Meu Perfil"** no menu
2. Navegue pelas abas:
   - **Informações:** Dados pessoais e da propriedade
   - **Avaliações:** Feedback de indústrias
   - **Configurações:** Notificações e segurança

---

### Cenário 2: Como Indústria 🏭

#### Passo 1: Fazer Login
1. Faça logout (se estiver logado como produtor)
2. Na landing page, clique em **"Entrar"**
3. Use as credenciais:
   - **E-mail:** `contato@riz.com.br`
   - **Senha:** `123456`
4. Clique em **"Entrar"**

#### Passo 2: Explorar o Dashboard
- ✅ Veja suas estatísticas de compras
- ✅ Analise o **Índice de Preços** do mercado
- ✅ Veja ofertas recomendadas

#### Passo 3: Buscar Ofertas
1. Clique em **"Buscar Ofertas"** no menu
2. Use a barra de busca ou clique em **"Filtros"**
3. Aplique filtros:
   - **Estado:** RS
   - **Variedade:** IRGA 424
   - **Preço:** R$ 80,00 - R$ 90,00
   - **Tipo:** Tipo 1
4. Clique em **"Aplicar"**
5. ✅ Veja as ofertas filtradas

#### Passo 4: Ver Detalhes de uma Oferta
1. Clique em qualquer card de oferta
2. ✅ Modal abrirá com todas as informações:
   - Preço, quantidade, umidade
   - Localização, frete
   - Descrição completa
   - Dados do produtor
3. Clique em **"Enviar Proposta"**

#### Passo 5: Enviar Proposta
1. No modal de proposta, preencha:
   - **Preço proposto:** R$ 86,00
   - **Quantidade:** 200 sacas
   - **Mensagem:** "Gostaria de negociar esta quantidade"
2. Clique em **"Enviar Proposta"**
3. ✅ Proposta enviada com sucesso!

#### Passo 6: Ver no Mapa
1. Clique em **"Mapa de Ofertas"** no menu
2. ✅ Veja todas as ofertas plotadas geograficamente
3. Clique nos marcadores coloridos para ver detalhes
4. Use a legenda para entender as cores

---

## 3️⃣ Funcionalidades para Testar

### ✅ Landing Page
- [x] Navegação suave entre seções
- [x] Menu mobile (reduza a janela)
- [x] Estatísticas animadas
- [x] Botões de CTA

### ✅ Autenticação
- [x] Login com e-mail
- [x] Cadastro de novo usuário
- [x] Validação de campos
- [x] Persistência de sessão

### ✅ Dashboard
- [x] Cards de estatísticas
- [x] Gráficos interativos
- [x] Lista de atividades
- [x] Índice de preços

### ✅ Ofertas
- [x] Criar nova oferta
- [x] Listar ofertas
- [x] Buscar e filtrar
- [x] Ver detalhes em modal
- [x] Ordenar resultados

### ✅ Mapa
- [x] Visualização geográfica
- [x] Marcadores coloridos
- [x] Popup com informações
- [x] Legenda explicativa

### ✅ Chat
- [x] Lista de conversas
- [x] Histórico de mensagens
- [x] Enviar novas mensagens
- [x] Indicador de não lidas

### ✅ Perfil
- [x] Visualizar dados pessoais
- [x] Ver avaliações recebidas
- [x] Configurações de notificações
- [x] Sistema de tabs

---

## 4️⃣ Atalhos de Teclado

Experimente estes atalhos enquanto usa o app:

- **Enter** no campo de mensagem → Enviar mensagem
- **Esc** (futuro) → Fechar modal
- **Tab** → Navegar entre campos de formulário

---

## 5️⃣ Responsividade

Teste o app em diferentes tamanhos de tela:

1. **Desktop (1920px):**
   - Abra em tela cheia
   - Todas as features visíveis

2. **Tablet (768px):**
   - Redimensione a janela
   - Sidebar se torna colapsável

3. **Mobile (375px):**
   - Reduza ainda mais
   - Menu hamburguer aparece
   - Layout se adapta

**Como testar no navegador:**
- Chrome/Edge: F12 → Toggle Device Toolbar (Ctrl+Shift+M)
- Firefox: F12 → Responsive Design Mode (Ctrl+Shift+M)

---

## 6️⃣ Dados de Teste Disponíveis

### Usuários Pré-cadastrados

| Tipo | E-mail | Senha | Nome |
|------|--------|-------|------|
| 🧑‍🌾 Produtor | joao.silva@email.com | 123456 | João Silva |
| 🏭 Indústria | contato@riz.com.br | 123456 | Indústria Riz S.A. |
| 🧑‍🌾 Produtor | maria.oliveira@email.com | 123456 | Maria Oliveira |

### Ofertas Disponíveis

- ✅ 5 ofertas ativas de arroz em casca
- ✅ Variedades: IRGA 424, GURI INTA CL, BR-IRGA 409
- ✅ Preços: R$ 82,00 - R$ 90,00/saca
- ✅ Localizações: Cachoeira do Sul, Santa Maria (RS)

---

## 7️⃣ Fluxo Completo Recomendado

### 🎯 Teste Completo em 10 Minutos

1. **Minuto 1-2:** Explore a landing page
   - Scroll pelas seções
   - Clique nos botões
   - Teste o menu mobile

2. **Minuto 3-4:** Login como produtor
   - Veja o dashboard
   - Crie uma oferta

3. **Minuto 5-6:** Logout e login como indústria
   - Busque ofertas
   - Aplique filtros
   - Veja no mapa

4. **Minuto 7-8:** Interaja com ofertas
   - Abra detalhes
   - Envie proposta
   - Favorite uma oferta

5. **Minuto 9:** Use o chat
   - Veja conversas
   - Envie mensagens

6. **Minuto 10:** Explore o perfil
   - Veja avaliações
   - Teste configurações

---

## 8️⃣ Recursos Avançados

### LocalStorage
Todos os dados são salvos no navegador:
```javascript
// Ver dados salvos (console do navegador - F12)
console.log(localStorage.getItem('mercadoArroz_users'));
console.log(localStorage.getItem('mercadoArroz_offers'));
console.log(localStorage.getItem('mercadoArroz_messages'));
```

### Limpar Dados
Para resetar o app:
```javascript
// No console do navegador (F12)
localStorage.clear();
location.reload();
```

---

## 9️⃣ Troubleshooting

### Problema: Página em branco
**Solução:** 
- Verifique o console (F12)
- Certifique-se de que os arquivos CSS e JS estão carregando
- Use um servidor local ao invés de abrir direto

### Problema: Mapa não carrega
**Solução:**
- Verifique sua conexão com internet (Leaflet precisa baixar tiles)
- Aguarde alguns segundos após abrir a página

### Problema: Gráficos não aparecem
**Solução:**
- Verifique se o Chart.js carregou (internet necessária)
- Recarregue a página

### Problema: Logout não funciona
**Solução:**
- Abra o console (F12)
- Digite: `localStorage.removeItem('mercadoArroz_currentUser')`
- Recarregue a página

---

## 🔟 Próximos Passos

Depois de testar o MVP, você pode:

1. **Personalizar Dados**
   - Edite `js/script.js` (função `initializeDatabase`)
   - Adicione mais usuários, ofertas, mensagens

2. **Modificar Cores**
   - Edite `css/style.css` (seção CSS Variables)
   - Altere as cores da marca

3. **Adicionar Páginas**
   - Copie uma página existente no `index.html`
   - Crie a navegação correspondente

4. **Implementar Backend**
   - Siga o guia no `README.md`
   - Conecte com API real

---

## 📞 Precisa de Ajuda?

- 📖 Leia o `README.md` completo
- 🔍 Veja o código comentado
- 💬 Console do navegador (F12) mostra erros

---

**Divirta-se explorando o Mercado Arroz!** 🌾🚀

*Versão: 1.0.0 | Status: ✅ Pronto para uso*